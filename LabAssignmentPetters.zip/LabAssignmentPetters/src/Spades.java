
public class Spades extends Suit {
	public Spades(){
		for(int i=0; i<cards.size(); i++){
			cards.get(i).setSuit("Spades");
		}
	}
}
