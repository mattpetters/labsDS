
public class Clubs extends Suit {
	public Clubs(){
		for(int i=0; i<cards.size(); i++){
			cards.get(i).setSuit("Clubs");
		}
	}
}
