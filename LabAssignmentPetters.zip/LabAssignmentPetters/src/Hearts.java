
public class Hearts extends Suit{

	public Hearts(){
		for(int i=0; i<cards.size(); i++){
			cards.get(i).setSuit("Hearts");
		}
	}
	
}
